# Changelog

## Unreleased

### Repository cleanup
- Added professional GitHub project documentation.
- Added secret-safe `.gitignore`.
- Added `.env.example`.
- Added dependency placeholder.
- Added migration helper for extracting the legacy ZIP packages.
- Defined recommended source-code structure.
- Documented IndiaMART output fields and specification workflow.

## Existing packaged builds

### V5.3 Shared Common Pro
Existing repository package:
`NUNES_INDIAMART_AUTOMATION_V5_3_SHARED_COMMON_PRO.zip`

### Fast V3 Exact Template
Existing repository package:
`NUNES_INDIAMART_PRODUCT_AUTOMATION_FAST_V3_EXACT_TEMPLATE.zip`
