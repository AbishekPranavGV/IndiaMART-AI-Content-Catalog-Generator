# IndiaMART AI Content & Catalog Generator

AI-assisted product-content and catalog generation system designed for industrial and laboratory product listings.

## Purpose

The project takes a product name, model, specification, supplier data, or product image and helps prepare structured IndiaMART-ready product content and catalog material.

The workflow focuses on generating the content and assets locally so the final IndiaMART listing can be reviewed and uploaded manually or through an approved integration.

## Core capabilities

- Product title cleanup and normalization
- AI-generated product descriptions
- Key features
- Industrial / laboratory applications
- Search keywords
- Product category suggestions
- Specification / Additional Details
- Catalog-ready images
- PDF / mini-catalog preparation
- Reusable product-content storage
- Product-model-aware generation
- India / Export-ready content workflow

## IndiaMART listing output

The intended generated structure is:

1. Product Name
2. Model
3. Description
4. Key Features
5. Applications
6. Search Keywords
7. Product Categories
8. Specification / Additional Details
9. Product Images
10. PDF / Mini Catalog

### Specification / Additional Details

Use relevant fields where applicable:

- Category
- Machine Position
- Spinning System
- Yarn Count Range
- Fiber Type
- Automation Grade
- Production Capacity
- Installed Power
- Brand Type
- Minimum Order Quantity
- Product / Service Code
- Delivery Time
- Packaging Details

## Recommended repository structure

```text
IndiaMART-AI-Content-Catalog-Generator/
├── app/
│   ├── main.py
│   ├── generator/
│   ├── catalog/
│   ├── image_processing/
│   ├── templates/
│   └── static/
├── data/
├── docs/
├── scripts/
├── tests/
├── .env.example
├── .gitignore
├── requirements.txt
├── README.md
└── CHANGELOG.md
```

## Existing packages

The original repository contained packaged builds such as:

- `NUNES_INDIAMART_AUTOMATION_V5_3_SHARED_COMMON_PRO.zip`
- `NUNES_INDIAMART_PRODUCT_AUTOMATION_FAST_V3_EXACT_TEMPLATE.zip`

Those ZIP files should be treated as legacy/release packages. For a maintainable GitHub project, extract the actual source files into normal project folders rather than keeping the code only inside ZIP files.

A migration helper is included:

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\EXTRACT_EXISTING_PACKAGE.ps1
```

## Environment setup

Copy:

```text
.env.example
```

to:

```text
.env
```

Then configure only the AI provider you use.

Example:

```env
AI_PROVIDER=gemini
GEMINI_API_KEY=your_key_here
OPENAI_API_KEY=
APP_PORT=8000
```

Never commit `.env` or API keys to GitHub.

## Python setup

Recommended: Python 3.11 or 3.12.

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

The exact startup command depends on the source package extracted from the existing build.

## Content-generation rules

Generated content should be:

- technically accurate
- based on verified product information when available
- free from invented specifications
- easy to copy into IndiaMART
- written for industrial B2B buyers
- reusable across catalog and listing workflows

When a specification is unknown, omit it or clearly mark it for verification rather than inventing a value.

## Images

Recommended image workflow:

- 5–6 useful product images per listing
- clean product presentation
- no unnecessary duplicate images
- consistent aspect ratio
- use product/model labels only where useful
- preserve the real equipment appearance where source images are available

## Security

Do not commit:

- API keys
- passwords
- OAuth secrets
- Gmail tokens
- Google credentials
- private supplier/customer data
- IndiaMART session cookies
- browser profiles

Use `.env` or a secure secret store.

## Release strategy

Use GitHub **Releases** for large packaged builds instead of storing every ZIP directly in the repository history.

Suggested release naming:

```text
IndiaMART AI Content & Catalog Generator v5.3
```

Suggested asset:

```text
NUNES_INDIAMART_AUTOMATION_V5_3_SHARED_COMMON_PRO.zip
```

## Current migration goal

The first cleanup of this repository should:

- keep the working packaged builds
- extract the latest source
- place source under `app/`
- remove duplicate README files
- add `.gitignore`
- add `.env.example`
- add dependency documentation
- add release notes
- avoid committing secrets
- keep old working versions available through GitHub Releases

## License

No license has been selected yet. Add an appropriate license only after confirming how the software may be shared and reused.
