# Migration Guide

## Why migrate

The current repository stores the working application mainly as ZIP archives. GitHub works best when actual source files are visible in the repository.

Benefits:

- readable source history
- meaningful diffs
- easier debugging
- GitHub code search
- easier collaboration
- proper releases
- simpler future updates

## Safe migration procedure

1. Keep both existing ZIPs unchanged as backups.
2. Download this GitHub-ready package.
3. Copy the helper files into the repository.
4. Put the existing ZIP packages in the repository root if they are not already there.
5. Run:

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\EXTRACT_EXISTING_PACKAGE.ps1
```

6. Inspect `_extracted_source`.
7. Identify the real Python/web application root.
8. Move only source/config/template assets into `app/`.
9. Do not copy virtual environments, cache folders, tokens, browser profiles, or generated output.
10. Test the application.
11. Commit the cleaned source.
12. Move large distributable ZIPs to GitHub Releases.

## Recommended first Git commit

```powershell
git add .
git commit -m "Restructure IndiaMART AI Content Catalog Generator project"
git push origin main
```

## Recommended next release

`v5.3.0`

Release title:

`IndiaMART AI Content & Catalog Generator v5.3`

Attach the tested deployment ZIP as a GitHub Release asset.
