param(
    [string]$RepositoryRoot = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
)

$ErrorActionPreference = "Stop"

Write-Host ""
Write-Host "====================================================="
Write-Host " IndiaMART AI Content Catalog - Source Migration"
Write-Host "====================================================="
Write-Host ""

$preferred = @(
    "NUNES_INDIAMART_AUTOMATION_V5_3_SHARED_COMMON_PRO.zip",
    "NUNES_INDIAMART_PRODUCT_AUTOMATION_FAST_V3_EXACT_TEMPLATE.zip"
)

$selected = $null

foreach ($name in $preferred) {
    $candidate = Join-Path $RepositoryRoot $name
    if (Test-Path $candidate) {
        $selected = $candidate
        break
    }

    $legacyCandidate = Join-Path (Join-Path $RepositoryRoot "legacy-packages") $name
    if (Test-Path $legacyCandidate) {
        $selected = $legacyCandidate
        break
    }
}

if (-not $selected) {
    Write-Host "[ERROR] No existing IndiaMART package ZIP was found."
    Write-Host ""
    Write-Host "Place one of these files in the repository root or legacy-packages:"
    foreach ($name in $preferred) {
        Write-Host " - $name"
    }
    exit 1
}

$staging = Join-Path $RepositoryRoot "_extracted_source"
if (Test-Path $staging) {
    Remove-Item $staging -Recurse -Force
}
New-Item -ItemType Directory -Path $staging | Out-Null

Write-Host "[INFO] Extracting:"
Write-Host "       $selected"
Expand-Archive -Path $selected -DestinationPath $staging -Force

Write-Host ""
Write-Host "[OK] Package extracted to:"
Write-Host "     $staging"
Write-Host ""
Write-Host "NEXT:"
Write-Host " 1. Inspect the extracted folder."
Write-Host " 2. Identify the real application/source root."
Write-Host " 3. Move source code into app/."
Write-Host " 4. Keep generated output and secrets out of Git."
Write-Host " 5. Update requirements.txt from the actual imports."
Write-Host ""
Write-Host "Do NOT delete the working package until the extracted app has been tested."
Write-Host ""
