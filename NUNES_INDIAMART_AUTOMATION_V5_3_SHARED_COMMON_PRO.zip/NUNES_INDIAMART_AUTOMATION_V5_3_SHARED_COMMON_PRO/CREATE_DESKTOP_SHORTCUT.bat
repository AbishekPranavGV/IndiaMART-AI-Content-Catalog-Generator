@echo off
powershell -NoProfile -File "%~dp0CREATE_DESKTOP_SHORTCUT.ps1"
pause
