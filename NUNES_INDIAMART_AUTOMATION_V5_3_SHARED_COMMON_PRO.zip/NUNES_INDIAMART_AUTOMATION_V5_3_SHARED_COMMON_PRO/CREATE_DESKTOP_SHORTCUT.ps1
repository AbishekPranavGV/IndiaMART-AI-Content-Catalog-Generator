$ErrorActionPreference = 'Stop'
$shortcutPath = Join-Path ([Environment]::GetFolderPath('Desktop')) 'Nunes Product Manager.lnk'
$wsh = New-Object -ComObject WScript.Shell
$link = $wsh.CreateShortcut($shortcutPath)
$link.TargetPath = Join-Path $PSScriptRoot 'START.bat'
$link.WorkingDirectory = $PSScriptRoot
$link.Description = 'Nunes local product manager'
$link.Save()
Write-Host 'Desktop shortcut created: Nunes Product Manager'
