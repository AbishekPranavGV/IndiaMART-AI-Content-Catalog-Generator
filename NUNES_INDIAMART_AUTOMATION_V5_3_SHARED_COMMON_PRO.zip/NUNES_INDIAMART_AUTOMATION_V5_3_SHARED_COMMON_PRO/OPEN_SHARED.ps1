$ErrorActionPreference = 'SilentlyContinue'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path

function Test-NetworkProjectPath([string]$path) {
    if ($path -like '\\*') { return $true }
    try {
        $driveName = (Split-Path -Qualifier $path).TrimEnd(':')
        if ($driveName) {
            $disk = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='$($driveName):'"
            if ($disk -and [int]$disk.DriveType -eq 4) { return $true }
        }
    } catch {}
    return $false
}

if (-not (Test-NetworkProjectPath $root)) {
    exit 10
}

$registration = Join-Path $root 'NUNES_SHARED_SERVER.json'
if (-not (Test-Path -LiteralPath $registration)) {
    Write-Host ''
    Write-Host 'NUNES shared server has not been registered yet.' -ForegroundColor Yellow
    Write-Host 'On the NUNES server PC, run START_LAN.bat once.'
    exit 30
}

try {
    $cfg = Get-Content -LiteralPath $registration -Raw | ConvertFrom-Json
} catch {
    Write-Host ''
    Write-Host 'The shared server registration file cannot be read.' -ForegroundColor Red
    Write-Host 'On the NUNES server PC, run START_LAN.bat again.'
    exit 30
}

$urls = @($cfg.urls) | Where-Object { $_ -match '^https?://' }
foreach ($baseUrl in $urls) {
    try {
        $healthUrl = $baseUrl.TrimEnd('/') + '/api/shared-status'
        $health = Invoke-RestMethod -Uri $healthUrl -Method Get -TimeoutSec 2
        if ($health.app -eq 'nunes-product-manager' -and $health.ok -eq $true) {
            $target = $baseUrl.TrimEnd('/') + '/products'
            Write-Host ''
            Write-Host '[OK] Opening the shared NUNES dashboard:' -ForegroundColor Green
            Write-Host "     $target"
            Write-Host "     IndiaMART accounts on server: $($health.account_count)"
            Start-Process $target
            exit 0
        }
    } catch {}
}

Write-Host ''
Write-Host 'The shared NUNES server is currently OFFLINE or unreachable.' -ForegroundColor Red
Write-Host 'Do not start a separate local copy from the Common folder.' -ForegroundColor Yellow
Write-Host 'On the NUNES server PC, run START_LAN.bat and keep that server window open.'
exit 20
