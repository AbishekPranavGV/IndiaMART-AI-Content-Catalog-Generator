@echo off
setlocal EnableExtensions
title NUNES V5.3 - Easy Product Center
pushd "%~dp0"
if errorlevel 1 exit /b 1

rem When START.bat is launched from the shared Common / Tailscale / NAS folder,
rem open the one central NUNES server instead of creating separate per-PC accounts.
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0OPEN_SHARED.ps1"
set "SHARED_RESULT=%ERRORLEVEL%"
if "%SHARED_RESULT%"=="0" (
  popd
  exit /b 0
)
if "%SHARED_RESULT%"=="10" goto local_start
goto shared_stop

:local_start
rem Local extracted copy: preserve the existing V5.2 behavior.
set "VENV_PYTHON=%LOCALAPPDATA%\NUNES_INDIAMART_AUTOMATION\venv\Scripts\python.exe"
if not exist "%VENV_PYTHON%" (
  call SETUP.bat
  if errorlevel 1 goto failed
)
"%VENV_PYTHON%" local_launcher.py
if errorlevel 1 goto failed
popd
exit /b 0

:shared_stop
echo.
echo ======================================================
echo  NUNES SHARED DASHBOARD - SERVER REQUIRED
echo ======================================================
echo This Common-folder copy is protected from creating a second,
echo separate IndiaMART account database on this PC.
echo.
echo On the NUNES server PC:
echo   1. Run START_LAN.bat
echo   2. Keep the server window open
echo   3. Run START.bat again on this staff PC
echo.
popd
pause
exit /b 2

:failed
echo Could not start. Review the error above.
popd
pause
exit /b 1
