@echo off
setlocal EnableExtensions
title NUNES V5.3 - SHARED SERVER - KEEP THIS WINDOW OPEN

pushd "%~dp0"
if errorlevel 1 (
  echo ERROR: Could not access project folder.
  pause
  exit /b 1
)

set "VENV_PYTHON=%LOCALAPPDATA%\NUNES_INDIAMART_AUTOMATION\venv\Scripts\python.exe"
if not exist "%VENV_PYTHON%" (
  call SETUP.bat
  if errorlevel 1 goto failed
)

set "APP_HOST=0.0.0.0"
set "APP_PORT=5077"

echo.
echo ======================================================
echo  NUNES V5.3 - SHARED INDIAMART SERVER
echo ======================================================
echo This is the ONE central server for products and IndiaMART accounts.
echo Staff should run START.bat from the Common folder.
echo Do not close this window while staff are using NUNES.
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0REGISTER_SHARED_SERVER.ps1" -Port %APP_PORT%
if errorlevel 1 (
  echo WARNING: Could not update the shared server registration file.
  echo Staff auto-open may not work until this is corrected.
)

echo.
echo Server local page: http://127.0.0.1:%APP_PORT%/products
echo.
start "" "http://127.0.0.1:%APP_PORT%/products"
"%VENV_PYTHON%" app.py
set "APP_EXIT=%ERRORLEVEL%"
popd
pause
exit /b %APP_EXIT%

:failed
echo.
echo Server setup failed. Review the error above.
popd
pause
exit /b 1
