#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
NUNES_VENV="${XDG_DATA_HOME:-$HOME/.local/share}/NUNES_INDIAMART_AUTOMATION/venv"
if [ ! -x "$NUNES_VENV/bin/python" ]; then
  python3 -m venv "$NUNES_VENV"
  "$NUNES_VENV/bin/python" setup_local.py
fi
exec "$NUNES_VENV/bin/python" local_launcher.py
