import json
import threading
from collections import Counter
from datetime import datetime, date
from pathlib import Path

ROOT = Path(__file__).resolve().parent
LOG = ROOT / "data" / "staff_activity.jsonl"
LOCK = threading.RLock()


def _clean(value, limit=200):
    return str(value or "").strip()[:limit]


def append(staff, action, product="", detail=""):
    item = {
        "at": datetime.now().isoformat(timespec="seconds"),
        "date": date.today().isoformat(),
        "staff": _clean(staff or "Unassigned", 80) or "Unassigned",
        "action": _clean(action, 80),
        "product": _clean(product, 200),
        "detail": _clean(detail, 500),
    }
    LOG.parent.mkdir(parents=True, exist_ok=True)
    with LOCK:
        with LOG.open("a", encoding="utf-8") as f:
            f.write(json.dumps(item, ensure_ascii=False) + "\n")
    return item


def recent(limit=200):
    if not LOG.exists():
        return []
    rows = []
    with LOCK:
        try:
            lines = LOG.read_text(encoding="utf-8").splitlines()[-max(1, min(int(limit), 2000)):]
        except Exception:
            return []
    for line in reversed(lines):
        try:
            item = json.loads(line)
            if isinstance(item, dict):
                rows.append(item)
        except Exception:
            pass
    return rows


def today_summary():
    today = date.today().isoformat()
    rows = [x for x in recent(2000) if x.get("date") == today]
    staff_counts = Counter(x.get("staff") or "Unassigned" for x in rows)
    action_counts = Counter(x.get("action") or "" for x in rows)
    return {
        "date": today,
        "total": len(rows),
        "staff": [{"staff": k, "count": v} for k, v in staff_counts.most_common()],
        "actions": dict(action_counts),
        "recent": rows[:60],
    }
