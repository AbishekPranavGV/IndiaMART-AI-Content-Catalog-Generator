import json
import threading
import time
from datetime import datetime
from pathlib import Path
from uuid import uuid4

import production_manager as pm
from fast_fill import generate_draft

LOCK = threading.RLock()
STATE = {
    "id": "",
    "status": "idle",
    "paused": False,
    "mode": "online",
    "total": 0,
    "completed": 0,
    "failed": 0,
    "current": "",
    "items": [],
    "started_at": "",
    "updated_at": "",
}


def _snapshot():
    with LOCK:
        return json.loads(json.dumps(STATE))


def status():
    return _snapshot()


def _write_draft(key, draft):
    path = pm.OUTPUTS / key / "catalog_research_draft.json"
    tmp = path.with_suffix("." + uuid4().hex + ".tmp")
    tmp.write_text(json.dumps({"created_at": datetime.now().isoformat(timespec="seconds"), "draft": draft}, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def read_draft(key):
    path = pm.OUTPUTS / key / "catalog_research_draft.json"
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def start(keys, mode="online"):
    keys = list(dict.fromkeys(str(x) for x in keys if str(x).strip()))[:100]
    if not keys:
        raise ValueError("Select at least one product.")
    if mode not in {"online", "local", "polish"}:
        raise ValueError("Invalid preparation mode.")
    with LOCK:
        if STATE["status"] in {"running", "paused"}:
            raise ValueError("A bulk preparation queue is already active.")
        STATE.clear()
        STATE.update({
            "id": uuid4().hex,
            "status": "running",
            "paused": False,
            "mode": mode,
            "total": len(keys),
            "completed": 0,
            "failed": 0,
            "current": "",
            "items": [{"id": k, "status": "queued", "message": ""} for k in keys],
            "started_at": datetime.now().isoformat(timespec="seconds"),
            "updated_at": datetime.now().isoformat(timespec="seconds"),
        })
        queue_id = STATE["id"]
    threading.Thread(target=_worker, args=(queue_id,), daemon=True).start()
    return _snapshot()


def _worker(queue_id):
    while True:
        with LOCK:
            if STATE.get("id") != queue_id:
                return
            if STATE.get("status") not in {"running", "paused"}:
                return
            if STATE.get("paused"):
                STATE["status"] = "paused"
                item = None
            else:
                STATE["status"] = "running"
                item = next((x for x in STATE["items"] if x["status"] == "queued"), None)
                if item:
                    item["status"] = "running"
                    STATE["current"] = item["id"]
                else:
                    STATE["status"] = "done"
                    STATE["current"] = ""
                    STATE["updated_at"] = datetime.now().isoformat(timespec="seconds")
                    return
        if item is None:
            time.sleep(0.35)
            continue
        key = item["id"]
        try:
            path = pm.OUTPUTS / key / "product_record.json"
            if not path.exists():
                raise RuntimeError("Product record not found.")
            record = json.loads(path.read_text(encoding="utf-8"))
            approved = record.get("approved", {}) or {}
            payload = {
                "name": approved.get("listing_name") or record.get("record_product_name") or key,
                "model": approved.get("model", ""),
                "mode": STATE.get("mode", "online"),
                "description": approved.get("description", ""),
                "source_row": (record.get("source", {}) or {}).get("sheet_row", {}) or {},
                "specifications": approved.get("specifications", []) or [],
                "refresh": False,
            }
            draft = generate_draft(payload)
            _write_draft(key, draft)
            with LOCK:
                item["status"] = "ready"
                item["message"] = "Research draft ready. Open and compare before applying."
                STATE["completed"] += 1
        except Exception as exc:
            with LOCK:
                item["status"] = "failed"
                item["message"] = str(exc)[:300]
                STATE["failed"] += 1
        finally:
            with LOCK:
                STATE["current"] = ""
                STATE["updated_at"] = datetime.now().isoformat(timespec="seconds")


def pause():
    with LOCK:
        if STATE.get("status") not in {"running", "paused"}:
            raise ValueError("No active bulk queue.")
        STATE["paused"] = True
        STATE["status"] = "paused"
    return _snapshot()


def resume():
    with LOCK:
        if STATE.get("status") not in {"running", "paused"}:
            raise ValueError("No paused bulk queue.")
        STATE["paused"] = False
        STATE["status"] = "running"
    return _snapshot()


def retry_failed():
    with LOCK:
        if STATE.get("status") in {"running", "paused"} and not STATE.get("paused"):
            raise ValueError("Pause the queue before retrying failed products.")
        failed = [x for x in STATE.get("items", []) if x.get("status") == "failed"]
        if not failed:
            raise ValueError("There are no failed products to retry.")
        for item in failed:
            item["status"] = "queued"
            item["message"] = ""
        STATE["failed"] = 0
        STATE["paused"] = False
        STATE["status"] = "running"
        queue_id = STATE["id"]
    threading.Thread(target=_worker, args=(queue_id,), daemon=True).start()
    return _snapshot()
