"""Product desk: existing records remain the source of truth."""
import hashlib
import json
import math
import re
from difflib import SequenceMatcher
import shutil
import subprocess
import tempfile
import threading
from datetime import datetime
from pathlib import Path
from uuid import uuid4
from flask import Blueprint, jsonify, render_template, request
from PIL import Image, ImageOps
import production_manager as pm
from product_record import new_record, clean_specs, sync_model_spec, PRICE_HEADERS, norm_header
from indiamart_accounts import read_matrix, load_accounts
from activity_log import append as log_activity, today_summary, recent as recent_activity
import bulk_queue

bp = Blueprint('catalog', __name__)
LOCK = threading.RLock()
BUSY = lambda: False


def staff_name():
    return str(request.headers.get("X-Nunes-Staff") or "Unassigned").strip()[:80] or "Unassigned"


def _words(value):
    return {x for x in re.findall(r"[a-z0-9]+", str(value or "").casefold()) if len(x) > 1}


def duplicate_score(name, model, record):
    a = record.get("approved", {}) or {}
    other_name = str(a.get("listing_name") or "")
    other_model = str(a.get("model") or "")
    model_exact = bool(model and other_model and re.sub(r"\W+", "", model.casefold()) == re.sub(r"\W+", "", other_model.casefold()))
    name_score = SequenceMatcher(None, str(name).casefold(), other_name.casefold()).ratio()
    overlap = len(_words(name) & _words(other_name)) / max(1, len(_words(name) | _words(other_name)))
    score = max(name_score, overlap) + (0.35 if model_exact else 0)
    return min(1.0, score), model_exact


def revision(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def target(key):
    if not key or key != Path(key).name or key in {'.', '..'}:
        raise ValueError('Invalid product identifier.')
    path = pm.OUTPUTS / key / 'product_record.json'
    if not path.is_file():
        raise ValueError('Product not found.')
    return path

def read(key):
    path = target(key)
    r = json.loads(path.read_text(encoding='utf-8'))
    r['_id'], r['_revision'] = key, revision(path)
    a, assets = r.get('approved', {}), r.get('assets', {})
    price = str(r.get('source', {}).get('selling_price', '')).replace(',', '').replace('₹', '').strip()
    try:
        valid_price = math.isfinite(float(price)) and float(price) > 0
    except ValueError:
        valid_price = False
    checks = {'category': bool(a.get('categories')), 'price': valid_price, 'specifications': bool(a.get('specifications')), 'images': bool(assets.get('images')), 'description': bool(a.get('description')), 'model': bool(a.get('model'))}
    r['_missing'] = [k for k,v in checks.items() if not v]
    r['_score'] = round(100 * sum(checks.values()) / len(checks))
    r['_updated'] = path.stat().st_mtime
    r['_indiamart_accounts'] = read_matrix(path.parent)
    draft = bulk_queue.read_draft(key)
    r['_research_draft'] = draft.get('draft') if isinstance(draft, dict) else None
    r['_draft_ready'] = bool(r['_research_draft'])
    status = str(r.get('status') or '')
    if status == 'SELLER_COMPLETED':
        r['_workflow_status'] = 'completed'
    elif status == 'READY_FOR_INDIAMART':
        r['_workflow_status'] = 'ready_indiamart'
    elif r['_missing']:
        r['_workflow_status'] = 'missing'
    else:
        r['_workflow_status'] = 'review'
    return r

def persist(key, r, expected):
    path = target(key)
    if revision(path) != expected:
        raise ValueError('This product changed in another window. Refresh and reopen before saving.')
    backup = path.parent / 'backups'
    backup.mkdir(exist_ok=True)
    shutil.copy2(path, backup / (datetime.now().strftime('%Y%m%d_%H%M%S_%f') + '_catalog.json'))
    for k in list(r):
        if k.startswith('_'): r.pop(k)
    r['status'] = 'REVIEW_READY'
    r.setdefault('timestamps', {})['catalog_updated_at'] = datetime.now().isoformat(timespec='seconds')
    r['timestamps'].pop('approved_at', None)
    assets = r.setdefault('assets', {})
    assets['pdf_path'] = assets['pdf_web_url'] = ''
    tmp = path.with_suffix('.' + uuid4().hex + '.tmp')
    tmp.write_text(json.dumps(r, ensure_ascii=False, indent=2), encoding='utf-8')
    tmp.replace(path)
    return read(key)

@bp.errorhandler(ValueError)
def invalid(exc):
    return jsonify(ok=False, message=str(exc)), 400

@bp.before_request
def guard():
    if request.method == 'POST' and BUSY():
        return jsonify(ok=False, message='Wait for the current product process to finish.'), 409

@bp.get('/products')
def page():
    return render_template('products.html')

@bp.get('/api/catalog')
def listing():
    items, errors = [], []
    pm.OUTPUTS.mkdir(exist_ok=True)
    for path in pm.OUTPUTS.glob('*/product_record.json'):
        try: items.append(read(path.parent.name))
        except (ValueError, OSError): errors.append(path.parent.name)
    return jsonify(ok=True, items=sorted(items, key=lambda r:r['_updated'], reverse=True), unreadable=errors, ocr_available=bool(shutil.which('tesseract')))

@bp.get('/api/catalog/duplicates')
def duplicates():
    name = str(request.args.get('name', '')).strip()[:200]
    model = str(request.args.get('model', '')).strip()[:150]
    if not name:
        return jsonify(ok=True, items=[])
    matches = []
    for path in pm.OUTPUTS.glob('*/product_record.json'):
        try:
            record = read(path.parent.name)
            score, model_exact = duplicate_score(name, model, record)
            if score >= 0.58 or model_exact:
                a = record.get('approved', {}) or {}
                matches.append({
                    'id': record['_id'], 'name': a.get('listing_name', ''), 'model': a.get('model', ''),
                    'score': round(score, 2), 'model_exact': model_exact, 'workflow_status': record.get('_workflow_status'),
                })
        except Exception:
            pass
    matches.sort(key=lambda x: (x['model_exact'], x['score']), reverse=True)
    return jsonify(ok=True, items=matches[:8])

@bp.post('/api/catalog/new')
def create():
    d = request.get_json() or {}
    name = str(d.get('name', '')).strip()[:200]
    model = str(d.get('model', '')).strip()[:150]
    action = str(d.get('duplicate_action') or 'keep_separate')
    if not name: raise ValueError('Enter a product name.')
    base = (name + (' ' + model if model else '')).strip() if action == 'create_variant' else name
    key = pm.safe_name(base)
    with LOCK:
        folder = pm.OUTPUTS / key
        if folder.exists():
            suffix = 2
            while (pm.OUTPUTS / f"{key}_{suffix}").exists(): suffix += 1
            key = f"{key}_{suffix}"
            folder = pm.OUTPUTS / key
        folder.mkdir(parents=True)
        r = new_record(name, model=model)
        # record_product_name is the stable internal workflow key. Keeping it
        # aligned to the folder lets variants / intentionally separate products
        # continue through PDF and IndiaMART without colliding by display name.
        r['record_product_name'] = key
        r['status'] = 'REVIEW_READY'
        r.setdefault('catalog', {})['duplicate_action'] = action
        if d.get('variant_of'):
            r['catalog']['variant_of'] = str(d.get('variant_of'))[:120]
        (folder / 'product_record.json').write_text(json.dumps(r, indent=2), encoding='utf-8')
    log_activity(staff_name(), 'created', name, action)
    return jsonify(ok=True, record=read(key))

@bp.post('/api/catalog/save')
def save():
    d = request.get_json() or {}
    with LOCK:
        r = read(d.get('id'))
        a = r.setdefault('approved', {})
        name = str(d.get('listing_name', '')).strip()[:200]
        if not name: raise ValueError('Product name is required.')
        categories = list(dict.fromkeys(str(x).strip()[:120] for x in d.get('categories', []) if str(x).strip()))
        if len(categories) > 2: raise ValueError('Choose up to two categories.')
        price = str(d.get('price', '')).strip().replace(',', '')
        if price:
            try: valid = math.isfinite(float(price)) and float(price) > 0
            except ValueError: valid = False
            if not valid: raise ValueError('Selling price must be a positive number, or leave it blank.')
        a.update(listing_name=name, product_name=name, model=str(d.get('model','')).strip()[:150], description=str(d.get('description',''))[:20000], categories=categories, group=str(d.get('group',''))[:120], price_unit=str(d.get('unit','Piece'))[:50])
        a['variant_name'] = (name + ' ' + a['model']).strip()
        for field in ('key_features','applications'):
            a[field] = [str(x).strip()[:1000] for x in d.get(field,[]) if str(x).strip()][:30]
        a['specifications'] = sync_model_spec(d.get('specifications',[]), a['model'])
        source = r.setdefault('source', {})
        source['selling_price'] = price
        row = source.setdefault('sheet_row', {})
        for k in list(row):
            if norm_header(k) in PRICE_HEADERS: row[k] = price
        row['Selling Price'] = price
        # Local metadata requires manual category/video confirmation on seller site.
        catalog = r.setdefault('catalog', {})
        catalog['seller_metadata_review_required'] = True
        spec_sources = d.get('spec_sources') if isinstance(d.get('spec_sources'), list) else []
        catalog['spec_sources'] = [
            {
                'name': str(x.get('name','')).strip()[:200],
                'source': str(x.get('source','Manual')).strip()[:80] or 'Manual',
                'source_url': str(x.get('source_url','')).strip()[:1000],
                'researched_at': str(x.get('researched_at','')).strip()[:40],
            }
            for x in spec_sources if isinstance(x, dict) and str(x.get('name','')).strip()
        ][:30]
        catalog['last_saved_by'] = staff_name()
        catalog['last_saved_at'] = datetime.now().isoformat(timespec='seconds')
        saved = persist(d['id'], r, d.get('revision'))
        log_activity(staff_name(), 'saved', name, f"{saved.get('_score', 0)}% complete")
        return jsonify(ok=True, record=saved)

@bp.post('/api/catalog/media')
def media():
    key = request.form.get('id')
    f = request.files.get('file')
    if not f: raise ValueError('Choose a file.')
    kind = request.form.get('kind','image')
    with LOCK:
        r = read(key)
        if r['_revision'] != request.form.get('revision'): raise ValueError('Product changed. Refresh before uploading.')
        folder = target(key).parent
        assets = r.setdefault('assets', {})
        if kind == 'image':
            if len(assets.get('images',[])) >= 5: raise ValueError('Five image slots are full. Remove an image first.')
            try:
                im = Image.open(f.stream)
                if im.width * im.height > 40000000: raise ValueError('Image is too large.')
                im = ImageOps.exif_transpose(im).convert('RGB')
                im.thumbnail((2400,2400))
            except Exception: raise ValueError('Choose a valid JPG, PNG or WEBP image.')
            digest = hashlib.sha256(im.tobytes()).hexdigest()
            known_hashes = list(assets.get('image_hashes', []))
            if digest in known_hashes:
                raise ValueError('This image is already attached to the product.')
            out = folder / 'images' / (uuid4().hex + '.jpg')
            out.parent.mkdir(exist_ok=True)
            im.save(out, quality=92)
            assets.setdefault('images', []).append(str(out.resolve()))
            known_hashes.append(digest)
            assets['image_hashes'] = known_hashes
            assets['image_web_urls'] = ['/outputs/' + key + '/images/' + Path(x).name for x in assets['images']]
        elif kind == 'pdf':
            raw = f.read()
            if not raw.startswith(b'%PDF-'): raise ValueError('Choose a valid PDF.')
            out = folder / ('attachment_' + uuid4().hex + '.pdf')
            out.write_bytes(raw)
            assets['attachment_pdf_url'] = '/outputs/' + key + '/' + out.name
        elif kind == 'video':
            raw = f.read()
            if len(raw) < 12 or raw[4:8] != b'ftyp': raise ValueError('Choose an MP4 video (maximum 30 MB).')
            out = folder / ('video_' + uuid4().hex + '.mp4')
            out.write_bytes(raw)
            assets['video_url'] = '/outputs/' + key + '/' + out.name
        else: raise ValueError('Unsupported media type.')
        return jsonify(ok=True, record=persist(key, r, request.form.get('revision')))

@bp.post('/api/catalog/image-action')
def image_action():
    d = request.get_json() or {}
    with LOCK:
        r = read(d.get('id'))
        assets = r.setdefault('assets', {})
        images = assets.get('images', [])
        i = int(d.get('index', -1))
        if not 0 <= i < len(images): raise ValueError('Select an image.')
        hashes = list(assets.get('image_hashes', []))
        if d.get('action') == 'primary':
            images.insert(0, images.pop(i))
            if i < len(hashes): hashes.insert(0, hashes.pop(i))
        elif d.get('action') == 'remove':
            images.pop(i)
            if i < len(hashes): hashes.pop(i)
        elif d.get('action') == 'move':
            target_i = int(d.get('target', i))
            if not 0 <= target_i < len(images): raise ValueError('Invalid image position.')
            images.insert(target_i, images.pop(i))
            if i < len(hashes): hashes.insert(target_i, hashes.pop(i))
        else: raise ValueError('Unknown action.')
        assets['image_hashes'] = hashes
        assets['image_web_urls'] = ['/outputs/' + d['id'] + '/images/' + Path(x).name for x in images]
        assets['image_locks'] = [False]*5
        saved = persist(d['id'], r, d.get('revision'))
        log_activity(staff_name(), 'media edited', saved.get('approved', {}).get('listing_name',''), d.get('action'))
        return jsonify(ok=True, record=saved)

@bp.post('/api/catalog/ocr')
def ocr():
    exe = shutil.which('tesseract')
    if not exe: raise ValueError('Image-to-text needs Tesseract OCR installed on this computer and added to PATH. Restart the app after installation.')
    f = request.files.get('file')
    if not f: raise ValueError('Choose an image containing text.')
    with tempfile.TemporaryDirectory() as td:
        path = Path(td) / 'text.png'
        try:
            im = Image.open(f.stream)
            if im.width*im.height > 40000000: raise ValueError()
            ImageOps.exif_transpose(im).convert('RGB').save(path)
        except Exception: raise ValueError('Choose a valid image under 40 megapixels.')
        try:
            result = subprocess.run([exe, str(path), 'stdout'], capture_output=True, text=True, timeout=30)
        except subprocess.TimeoutExpired: raise ValueError('Text extraction took too long. Try a smaller, clearer image.')
        if result.returncode: raise ValueError('OCR failed. Try a clearer image.')
        return jsonify(ok=True, text=result.stdout[:30000])

@bp.post('/api/catalog/autofill')
def autofill_start():
    from fast_fill import start_job
    d = request.get_json() or {}
    name = str(d.get('name', '')).strip()[:200]
    if not name: raise ValueError('Enter the product name first.')
    if d.get('mode') not in {'online','local','polish'}: raise ValueError('Choose an auto-fill mode.')
    row = {}
    if d.get('id'):
        record = read(d['id'])
        approved = record.get('approved', {})
        # Source data belongs only to the exact product/model being edited.
        if name.casefold() == str(approved.get('listing_name','')).casefold() and str(d.get('model','')).casefold() == str(approved.get('model','')).casefold():
            row = record.get('source', {}).get('sheet_row', {})
    return jsonify(ok=True, job_id=start_job({
        'name':name, 'model':str(d.get('model',''))[:150], 'mode':d['mode'],
        'description':str(d.get('description',''))[:20000], 'source_row':row,
        'specifications':clean_specs(d.get('specifications',[])), 'refresh':bool(d.get('refresh')),
    }))

@bp.get('/api/catalog/autofill/<job_id>')
def autofill_status(job_id):
    from fast_fill import get_job
    return jsonify(ok=True, **get_job(job_id))

@bp.get('/api/catalog/category-suggestions')
def category_suggestions():
    name = str(request.args.get('name', '')).strip()[:200]
    model = str(request.args.get('model', '')).strip()[:150]
    words = _words(name + ' ' + model)
    scores = {}
    examples = {}
    for path in pm.OUTPUTS.glob('*/product_record.json'):
        try:
            r = json.loads(path.read_text(encoding='utf-8'))
            a = r.get('approved', {}) or {}
            other_words = _words((a.get('listing_name') or '') + ' ' + (a.get('model') or ''))
            if not words or not other_words:
                continue
            overlap = len(words & other_words) / max(1, len(words | other_words))
            if overlap <= 0:
                continue
            for category in a.get('categories', []) or []:
                category = str(category).strip()
                if not category:
                    continue
                if overlap > scores.get(category, 0):
                    scores[category] = overlap
                    examples[category] = a.get('listing_name') or ''
        except Exception:
            pass
    items = [
        {'category': c, 'source': 'Local catalogue', 'score': round(score, 2), 'explanation': f"Similar to saved product: {examples.get(c,'')}"}
        for c, score in sorted(scores.items(), key=lambda x: x[1], reverse=True)[:2]
    ]
    return jsonify(ok=True, items=items)


@bp.get('/api/catalog/activity')
def activity():
    return jsonify(ok=True, summary=today_summary(), recent=recent_activity(150))


@bp.get('/api/catalog/backups/<key>')
def backups(key):
    path = target(key)
    folder = path.parent / 'backups'
    items = []
    if folder.exists():
        for item in sorted(folder.glob('*.json'), key=lambda p: p.stat().st_mtime, reverse=True)[:30]:
            try:
                data = json.loads(item.read_text(encoding='utf-8'))
                catalog = data.get('catalog', {}) or {}
                items.append({
                    'name': item.name,
                    'at': datetime.fromtimestamp(item.stat().st_mtime).isoformat(timespec='seconds'),
                    'staff': catalog.get('last_saved_by', ''),
                    'product': (data.get('approved', {}) or {}).get('listing_name', ''),
                })
            except Exception:
                items.append({'name': item.name, 'at': datetime.fromtimestamp(item.stat().st_mtime).isoformat(timespec='seconds'), 'staff': '', 'product': ''})
    return jsonify(ok=True, items=items)


@bp.post('/api/catalog/restore')
def restore_catalog_backup():
    d = request.get_json() or {}
    key = str(d.get('id') or '')
    backup_name = str(d.get('backup') or '')
    path = target(key)
    folder = path.parent / 'backups'
    candidate = folder / Path(backup_name).name
    if not backup_name or not candidate.is_file() or candidate.parent != folder:
        raise ValueError('Choose a valid recovery version.')
    with LOCK:
        current_backup = folder / (datetime.now().strftime('%Y%m%d_%H%M%S_%f') + '_before_restore.json')
        shutil.copy2(path, current_backup)
        shutil.copy2(candidate, path)
    restored = read(key)
    log_activity(staff_name(), 'restored', (restored.get('approved', {}) or {}).get('listing_name',''), backup_name)
    return jsonify(ok=True, record=restored)


@bp.get('/api/catalog/bulk/status')
def bulk_status():
    return jsonify(ok=True, queue=bulk_queue.status())


@bp.post('/api/catalog/bulk/start')
def bulk_start():
    d = request.get_json() or {}
    keys = d.get('ids') if isinstance(d.get('ids'), list) else []
    mode = str(d.get('mode') or 'online')
    queue = bulk_queue.start(keys, mode)
    log_activity(staff_name(), 'bulk prepared', '', f"{len(keys)} products · {mode}")
    return jsonify(ok=True, queue=queue)


@bp.post('/api/catalog/bulk/pause')
def bulk_pause():
    return jsonify(ok=True, queue=bulk_queue.pause())


@bp.post('/api/catalog/bulk/resume')
def bulk_resume():
    return jsonify(ok=True, queue=bulk_queue.resume())


@bp.post('/api/catalog/bulk/retry')
def bulk_retry():
    return jsonify(ok=True, queue=bulk_queue.retry_failed())
