"""Read-only auto-fill drafts and reusable, identity-specific research cache."""
import hashlib
import json
import re
import threading
import time
from datetime import datetime
from pathlib import Path
from urllib.parse import quote_plus, urlparse
from uuid import uuid4
from ai_client import ProductAI
from product_record import clean_specs, detect_model, sync_model_spec, extract_selling_price
from public_indiamart import PublicIndiaMartResearch

CACHE = Path(__file__).resolve().parent / 'data' / 'research_cache'
JOBS = {}
JOB_LOCK = threading.Lock()

def model_matches(model, result):
    if not model: return True
    detected = detect_model(result.get('specifications', []))
    if detected:
        return re.sub(r'\s+', '', detected).casefold() == re.sub(r'\s+', '', model).casefold()
    return bool(re.search(r'(?<![a-z0-9])'+re.escape(model)+r'(?![a-z0-9])', result.get('title',''), re.I))

def cache_read(key):
    try:
        d=json.loads((CACHE/(key+'.json')).read_text(encoding='utf-8'))
        if time.time()-d['at'] < 86400:
            result=dict(d['result'])
            result['researched_at']=datetime.fromtimestamp(d['at']).isoformat(timespec='seconds')
            return result
    except (OSError, ValueError, KeyError): pass
    return None

def cache_write(key,result):
    CACHE.mkdir(parents=True,exist_ok=True)
    p=CACHE/(key+'.'+uuid4().hex+'.tmp')
    p.write_text(json.dumps({'at':time.time(),'result':result},ensure_ascii=False),encoding='utf-8')
    p.replace(CACHE/(key+'.json'))

class FastResearch(PublicIndiaMartResearch):
    def __init__(self,event=None):
        super().__init__(event)
        self.deadline=time.monotonic()+50
    def navigate(self,url):
        left=self.deadline-time.monotonic()
        if left<=0: raise TimeoutError('Research time budget reached.')
        self.page.goto(url,wait_until='domcontentloaded',timeout=min(12000,int(left*1000)))
        try:self.page.wait_for_selector('a[href],h1',timeout=1200)
        except Exception:pass
    def links(self,query):
        # One browser call replaces hundreds of per-anchor calls.
        raw=self.page.locator('a[href]').evaluate_all("els=>els.slice(0,420).map(a=>({url:a.href,text:(a.innerText||a.title||'').slice(0,300)}))")
        out=[];seen=set()
        for x in raw:
            url=self._clean_result_url(x['url']);host=urlparse(url).hostname or ''
            if not (host=='indiamart.com' or host.endswith('.indiamart.com')) or '/proddetail/' not in url or url in seen:continue
            score=self._score_text(query,x['text']+' '+url)
            if score>0:out.append({'url':url,'score':score});seen.add(url)
        return sorted(out,key=lambda x:-x['score'])[:2]
    def lookup(self,product,model):
        query=(product+' '+model).strip();self.start(True)
        self.page.set_default_timeout(1000)
        # Public research does not need fonts, video or image downloads.
        self.context.route('**/*',lambda route:route.abort() if route.request.resource_type in {'image','media','font'} else route.continue_())
        links=[]
        for url in ['https://dir.indiamart.com/search.mp?ss='+quote_plus(query),'https://html.duckduckgo.com/html/?q='+quote_plus(query+' indiamart')]:
            self.event('PUBLIC_SEARCH','Searching matching product evidence…',15)
            try:self.navigate(url);links=self.links(query)
            except Exception:continue
            if links:break
        for link in links:
            if time.monotonic()>self.deadline:break
            try:
                self.navigate(link['url'])
                if not self._is_indiamart_managed_page():continue
                result=self._extract_current_page(query)
                if result.get('match_score',0)<0.5 or not model_matches(model,result):continue
                if result.get('description') or result.get('specifications'):
                    return {**result,'found':True,'scan_count':1,'message':'Matching public evidence found. Review details before saving.'}
            except Exception:continue
        return {'found':False,'description':'','specifications':[],'image_urls':[],'message':'No matching evidence found. Existing details are retained; add missing information manually.'}

def lookup_research(product,model='',refresh=False,event=None):
    key=hashlib.sha256(json.dumps(['v42',product.strip().casefold(),model.strip().casefold()]).encode()).hexdigest()
    cached=None if refresh else cache_read(key)
    if cached:return {**cached,'cache_hit':True}
    browser=FastResearch(event)
    try:result=browser.lookup(product,model)
    except Exception as exc:result={'found':False,'description':'','specifications':[],'image_urls':[],'message':'Public research unavailable: '+str(exc).splitlines()[0][:180]}
    finally:browser.close()
    if result.get('found'):cache_write(key,result)
    result.setdefault('researched_at', datetime.now().isoformat(timespec='seconds'))
    return {**result,'cache_hit':False}

def generate_draft(payload):
    started=time.perf_counter()
    name=str(payload['name']).strip();model=str(payload.get('model','')).strip()
    research=lookup_research(name,model,bool(payload.get('refresh'))) if payload.get('mode')=='online' else {}
    source=payload.get('source_row',{}) or {}
    source_specs=[]
    for key,value in source.items():
        if re.search(r'price|cost|margin|supplier|contact|phone|email|status|date|image|url|description|category|group|product|name|row|sheet',str(key),re.I):continue
        if str(value or '').strip():source_specs.append({'name':str(key),'value':str(value)})
    saved_specs=clean_specs(payload.get('specifications',[]))
    specs=[{**x,'source':'Saved / Manual','source_url':'','researched_at':''} for x in saved_specs]
    existing_names={x['name'].casefold() for x in specs}
    for x in clean_specs(source_specs):
        if x['name'].casefold() not in existing_names:
            specs.append({**x,'source':'Google Sheet','source_url':'','researched_at':''});existing_names.add(x['name'].casefold())
    research_url=research.get('product_url') or research.get('source_url') or ''
    research_at=research.get('researched_at') or datetime.now().isoformat(timespec='seconds')
    for x in clean_specs(research.get('specifications',[])):
        if x['name'].casefold() not in existing_names:
            specs.append({**x,'source':'IndiaMART','source_url':research_url,'researched_at':research_at});existing_names.add(x['name'].casefold())
    row={'Product Name':name,**{x['name']:x['value'] for x in specs}}
    if model:row['Model']=model
    description=payload.get('description') or research.get('description','')
    ai=ProductAI()
    if payload.get('mode')=='polish':
        ai.timeout=15
        content=ai.create_content(name,row,description)
    else:
        # Deterministic, evidence-only formatting has no model startup delay.
        apps=ai._extract_explicit_applications(row)
        content={'listing_name':name,'model':model or detect_model(specs),'description':ai._safe_description(name,specs,description) if (description or specs) else '', 'key_features':ai._safe_features(specs),'applications':ai._safe_applications(apps) if apps else ai._applications_from_public_description(description),'specifications':specs}
    content['listing_name']=name
    content['model']=model or detect_model(specs)
    cleaned_for_model=sync_model_spec(specs,content['model'])
    source_by_name={str(x.get('name','')).casefold():x for x in specs}
    content['specifications']=[{**x, **{k:v for k,v in source_by_name.get(str(x.get('name','')).casefold(),{}).items() if k in {'source','source_url','researched_at'}}} for x in cleaned_for_model]
    content['selling_price']=extract_selling_price(source)
    content['categories']=[str(v).strip() for k,v in source.items() if str(k).strip().casefold() in {'category','category 1','category 2'} and str(v or '').strip()][:2]
    content['group']=next((str(v) for k,v in source.items() if str(k).strip().casefold()=='group'),'')
    content['sources']=[research['product_url']] if research.get('product_url') else []
    content['image_urls']=research.get('image_urls',[])
    content['cache_hit']=bool(research.get('cache_hit'))
    content['researched_at']=research.get('researched_at') or datetime.now().isoformat(timespec='seconds')
    content['identity_check']={
        'product': name,
        'model': model,
        'exact_model_match': bool(not model or model_matches(model,research)) if research else True,
        'evidence_found': bool(research.get('found')),
        'match_score': research.get('match_score',0),
    }
    category_suggestions=[]
    for c in content.get('categories',[])[:2]:
        category_suggestions.append({'category':c,'source':'Google Sheet','explanation':'This category is already present in the source Sheet for this product.'})
    content['category_suggestions']=category_suggestions
    content['message']=research.get('message') or 'Prepared from the supplied evidence. Missing facts are left blank.'
    content['elapsed_seconds']=round(time.perf_counter()-started,2)
    return content

def start_job(payload):
    with JOB_LOCK:
        now=time.time()
        for k in list(JOBS):
            if now-JOBS[k]['created']>1800 and JOBS[k]['status']!='running':JOBS.pop(k)
        if any(x['status']=='running' for x in JOBS.values()):raise ValueError('Another auto-fill is running. Wait for it to finish.')
        while len(JOBS)>=50:JOBS.pop(next(iter(JOBS)))
        key=uuid4().hex;JOBS[key]={'status':'running','created':now}
    def worker():
        try:result={'status':'done','draft':generate_draft(payload)}
        except Exception as exc:result={'status':'error','message':str(exc)[:300]}
        with JOB_LOCK:JOBS[key].update(result)
    threading.Thread(target=worker,daemon=True).start()
    return key

def get_job(key):
    with JOB_LOCK:
        if key not in JOBS:raise ValueError('Auto-fill session expired. Start again.')
        return dict(JOBS[key])
