import json
import os
import re
import threading
import time
from datetime import datetime
from pathlib import Path
from uuid import uuid4

ROOT = Path(__file__).resolve().parent
_LOCK = threading.RLock()


def runtime_root():
    base = Path(os.getenv("LOCALAPPDATA", str(ROOT / "data"))) / "NUNES_INDIAMART_AUTOMATION" / "runtime"
    base.mkdir(parents=True, exist_ok=True)
    return base


def accounts_file():
    return runtime_root() / "indiamart_accounts.json"


def sessions_dir():
    path = runtime_root() / "indiamart_accounts"
    path.mkdir(parents=True, exist_ok=True)
    return path


def _slug(value):
    value = re.sub(r"[^a-z0-9]+", "-", str(value or "").lower()).strip("-")
    return value[:48] or uuid4().hex[:10]


def _read_raw():
    path = accounts_file()
    if not path.exists():
        return {"schema_version": 1, "accounts": []}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(data, dict) or not isinstance(data.get("accounts"), list):
            raise ValueError()
        return data
    except Exception:
        return {"schema_version": 1, "accounts": []}


def _write_raw(data):
    path = accounts_file()
    tmp = path.with_suffix("." + uuid4().hex + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def _state_path(account_id):
    return sessions_dir() / f"{_slug(account_id)}.json"


def discover_chrome_profiles():
    """Discover Chrome profiles without reading passwords or private browsing data."""
    localapp = Path(os.getenv("LOCALAPPDATA", str(Path.home())))
    configured = os.getenv("CHROME_USER_DATA_DIR", "").strip()
    user_data_dir = Path(os.path.expandvars(configured)).expanduser() if configured else localapp / "Google" / "Chrome" / "User Data"
    if not user_data_dir.exists():
        return []

    info_cache = {}
    last_used = ""
    try:
        state = json.loads((user_data_dir / "Local State").read_text(encoding="utf-8"))
        profile = state.get("profile", {}) or {}
        info_cache = profile.get("info_cache", {}) or {}
        last_used = str(profile.get("last_used") or "")
    except Exception:
        pass

    candidates = set(info_cache)
    try:
        for path in user_data_dir.iterdir():
            if path.is_dir() and (path.name == "Default" or path.name.startswith("Profile ")):
                candidates.add(path.name)
    except Exception:
        pass

    items = []
    for directory in sorted(candidates, key=lambda x: (x != last_used, x != "Default", x.lower())):
        meta = info_cache.get(directory, {}) if isinstance(info_cache, dict) else {}
        name = str(meta.get("name") or directory).strip()
        email = str(meta.get("user_name") or meta.get("gaia_name") or "").strip()
        label = name if not email else f"{name} · {email}"
        items.append({
            "profile_directory": directory,
            "profile_name": name,
            "email": email,
            "label": label,
            "last_used": directory == last_used,
            "user_data_dir": str(user_data_dir),
        })
    return items


def load_accounts(include_legacy=True):
    with _LOCK:
        data = _read_raw()
        accounts = []
        for item in data.get("accounts", []):
            if not isinstance(item, dict):
                continue
            account = dict(item)
            account.setdefault("enabled", True)
            account.setdefault("label", account.get("email") or account.get("profile_directory") or account.get("id", "IndiaMART"))
            account["state_path"] = str(_state_path(account.get("id")))
            state = Path(account["state_path"])
            account["has_saved_session"] = state.exists() and state.stat().st_size > 10
            accounts.append(account)

        if include_legacy:
            legacy_state = Path(os.getenv("INDIAMART_STORAGE_STATE", str(runtime_root() / "indiamart_storage_state.json"))).expanduser().resolve()
            # Preserve a real V4.2 legacy session, but never show an empty phantom
            # "Default IndiaMART Account" on a fresh/shared dashboard. This keeps the
            # displayed count aligned with accounts that were actually added/connected.
            legacy_ready = legacy_state.exists() and legacy_state.stat().st_size > 10
            if legacy_ready and not any(x.get("id") == "default" for x in accounts):
                accounts.insert(0, {
                    "id": "default",
                    "label": "Default IndiaMART Account",
                    "email": "",
                    "profile_directory": os.getenv("CHROME_PROFILE_DIRECTORY", "auto").strip() or "auto",
                    "user_data_dir": os.getenv("CHROME_USER_DATA_DIR", "").strip(),
                    "enabled": True,
                    "legacy": True,
                    "state_path": str(legacy_state),
                    "has_saved_session": legacy_state.exists() and legacy_state.stat().st_size > 10,
                    "created_at": "",
                    "last_verified_at": "",
                    "last_status": "unknown",
                    "last_message": "",
                })
        return accounts


def get_account(account_id=None):
    accounts = load_accounts(include_legacy=True)
    if account_id:
        for item in accounts:
            if item.get("id") == account_id:
                return item
        raise ValueError("IndiaMART account was not found. Refresh the account list.")
    if not accounts:
        raise ValueError("No IndiaMART account is configured.")
    return accounts[0]


def add_account(profile_directory, label="", email="", user_data_dir=""):
    profile_directory = str(profile_directory or "").strip()
    if not profile_directory:
        raise ValueError("Choose a Chrome profile.")
    discovered = {x["profile_directory"]: x for x in discover_chrome_profiles()}
    meta = discovered.get(profile_directory, {})
    label = str(label or meta.get("profile_name") or meta.get("label") or profile_directory).strip()[:120]
    email = str(email or meta.get("email") or "").strip()[:180]
    user_data_dir = str(user_data_dir or meta.get("user_data_dir") or "").strip()

    with _LOCK:
        data = _read_raw()
        for existing in data.get("accounts", []):
            if str(existing.get("profile_directory")) == profile_directory and str(existing.get("user_data_dir") or "") == user_data_dir:
                return normalize_account(existing)
        account_id = _slug(email or label or profile_directory) + "-" + uuid4().hex[:6]
        item = {
            "id": account_id,
            "label": label,
            "email": email,
            "profile_directory": profile_directory,
            "user_data_dir": user_data_dir,
            "enabled": True,
            "created_at": datetime.now().isoformat(timespec="seconds"),
            "last_verified_at": "",
            "last_status": "unknown",
            "last_message": "",
        }
        data.setdefault("accounts", []).append(item)
        _write_raw(data)
        return normalize_account(item)


def normalize_account(item):
    account = dict(item or {})
    account.setdefault("enabled", True)
    state_path = _state_path(account.get("id"))
    account["state_path"] = str(state_path)
    account["has_saved_session"] = state_path.exists() and state_path.stat().st_size > 10
    return account


def update_account(account_id, **changes):
    allowed = {"label", "email", "enabled", "last_verified_at", "last_status", "last_message"}
    with _LOCK:
        data = _read_raw()
        for item in data.get("accounts", []):
            if item.get("id") == account_id:
                for key, value in changes.items():
                    if key in allowed:
                        item[key] = value
                _write_raw(data)
                return normalize_account(item)
    if account_id == "default":
        return get_account("default")
    raise ValueError("IndiaMART account was not found.")


def remove_account(account_id):
    if account_id == "default":
        raise ValueError("The compatibility default account cannot be removed. Add a named account first.")
    with _LOCK:
        data = _read_raw()
        before = len(data.get("accounts", []))
        data["accounts"] = [x for x in data.get("accounts", []) if x.get("id") != account_id]
        if len(data["accounts"]) == before:
            raise ValueError("IndiaMART account was not found.")
        _write_raw(data)
    try:
        _state_path(account_id).unlink(missing_ok=True)
    except Exception:
        pass
    return True


def browser_kwargs(account):
    account = account or get_account()
    kwargs = {
        "state_path": account.get("state_path") or str(_state_path(account.get("id"))),
        "chrome_profile_directory": account.get("profile_directory") or "auto",
        "account_label": account.get("label") or "IndiaMART",
    }
    if account.get("user_data_dir"):
        kwargs["chrome_user_data_dir"] = account.get("user_data_dir")
    return kwargs


def matrix_path(product_folder):
    return Path(product_folder) / "indiamart_accounts.json"


def read_matrix(product_folder):
    path = matrix_path(product_folder)
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def write_matrix_result(product_folder, account_id, result):
    path = matrix_path(product_folder)
    with _LOCK:
        data = read_matrix(product_folder)
        data[str(account_id)] = dict(result or {})
        tmp = path.with_suffix("." + uuid4().hex + ".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(path)
    return data[str(account_id)]


JOBS = {}
JOB_LOCK = threading.RLock()


def start_job(kind, payload, worker):
    job_id = uuid4().hex
    with JOB_LOCK:
        JOBS[job_id] = {"id": job_id, "kind": kind, "status": "running", "created": time.time(), "progress": 0, "message": "Starting…", "results": []}
    def run():
        try:
            worker(job_id, payload)
            with JOB_LOCK:
                if JOBS[job_id]["status"] == "running":
                    JOBS[job_id].update(status="done", progress=100, message="Completed.")
        except Exception as exc:
            with JOB_LOCK:
                JOBS[job_id].update(status="error", progress=100, message=str(exc)[:500])
    threading.Thread(target=run, daemon=True).start()
    return job_id


def update_job(job_id, **changes):
    with JOB_LOCK:
        if job_id in JOBS:
            JOBS[job_id].update(changes)


def get_job(job_id):
    with JOB_LOCK:
        if job_id not in JOBS:
            raise ValueError("IndiaMART check session expired. Start the check again.")
        return dict(JOBS[job_id])
