"""Open the local UI when ready; reuse a running instance of this installation."""
import hashlib
import json
import os
import threading
import time
import urllib.request
import webbrowser
from pathlib import Path

ROOT=Path(__file__).resolve().parent
IDENTITY=hashlib.sha256(str(ROOT).encode()).hexdigest()[:16]

def main():
    os.chdir(ROOT)
    # START.bat is a local-only launcher. START_LAN.bat remains an explicit option.
    os.environ['APP_HOST']='127.0.0.1'
    from config_manager import load_configuration
    load_configuration()
    port=int(os.getenv('APP_PORT','5077'))
    url=f'http://127.0.0.1:{port}'
    opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
    def existing():
        try:
            with opener.open(url+'/api/local-info',timeout=.5) as r:return json.load(r)
        except Exception:return {}
    if existing().get('installation')==IDENTITY:
        webbrowser.open(url+'/products');return
    from app import app
    from waitress import serve
    def open_when_ready():
        for _ in range(100):
            if existing().get('installation')==IDENTITY:
                webbrowser.open(url+'/products');return
            time.sleep(.15)
    threading.Thread(target=open_when_ready,daemon=True).start()
    print('NUNES V5.3 local application: '+url)
    print('Keep this window open while using the application.')
    try:serve(app,host='127.0.0.1',port=port,threads=8)
    except OSError as exc:
        print('Could not start. The selected port may be used by another application: '+str(exc))
        raise SystemExit(1)
if __name__=='__main__':main()
