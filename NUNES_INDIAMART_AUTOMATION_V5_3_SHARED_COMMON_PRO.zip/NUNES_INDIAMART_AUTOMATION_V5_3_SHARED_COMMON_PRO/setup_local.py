"""Install only changed dependencies; never download AI models automatically."""
import hashlib
import subprocess
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def main():
    requirements=ROOT/'requirements.txt'
    expected=hashlib.sha256(requirements.read_bytes()).hexdigest()
    marker=Path(sys.prefix)/'nunes_requirements.sha256'
    ready=marker.exists() and marker.read_text()==expected
    if ready:
        check=subprocess.run([sys.executable,'-c','import flask,waitress,playwright,requests,PIL,reportlab,pypdf,dotenv'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        ready=check.returncode==0
    if not ready:
        subprocess.run([sys.executable,'-m','pip','install','--disable-pip-version-check','-r',str(requirements)],check=True)
        marker.write_text(expected)
    else:print('Dependencies already installed. Skipping package installation.')
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:browser_ready=Path(p.chromium.executable_path).exists()
    if not browser_ready:subprocess.run([sys.executable,'-m','playwright','install','chromium'],check=True)
    else:print('Chromium already installed. Skipping browser download.')
    print('Local setup ready. Local AI is optional; no AI model download was started.')
if __name__=='__main__':main()
