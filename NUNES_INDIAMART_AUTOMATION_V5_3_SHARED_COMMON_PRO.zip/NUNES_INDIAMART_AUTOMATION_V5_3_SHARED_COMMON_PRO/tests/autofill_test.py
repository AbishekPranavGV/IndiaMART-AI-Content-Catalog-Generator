"""Offline checks for manual approval boundaries and faster evidence reuse."""
import hashlib
import json
import sys
import tempfile
import time
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from flask import Flask
import fast_fill as ff
import catalog_manager as cm
from indiamart import IndiaMartBrowser

def main():
    assert ff.model_matches('AX224',{'title':'Balance AX224'})
    assert not ff.model_matches('AX224',{'title':'Balance AX224E'})
    assert not ff.model_matches('AX224',{'title':'AX224','specifications':[{'name':'Model','value':'AX223'}]})
    with patch.object(ff,'lookup_research',side_effect=AssertionError('Local fill must not access the web')):
        d=ff.generate_draft({'name':'Evidence meter','model':'M100','mode':'local','source_row':{'Purchase Price':'secret-cost','Selling Price':'2500','Range':'0 to 100 V','Category':'Meters','Group':'Electrical'},'specifications':[]})
    assert d['selling_price']=='2500' and d['categories']==['Meters']
    assert 'secret-cost' not in json.dumps(d)
    assert {'name':'Range','value':'0 to 100 V'} in d['specifications']
    assert ff.generate_draft({'name':'Unknown','mode':'local'})['description']==''
    with tempfile.TemporaryDirectory() as td:
        old_cache=ff.CACHE;ff.CACHE=Path(td)/'cache'
        fake={'found':True,'title':'Meter M100','product_url':'https://www.indiamart.com/proddetail/test','specifications':[]}
        with patch.object(ff.FastResearch,'lookup',return_value=fake) as lookup:
            first=ff.lookup_research('Meter','M100');second=ff.lookup_research('Meter','M100')
            assert not first['cache_hit'] and second['cache_hit'] and lookup.call_count==1
            ff.lookup_research('Meter','M101');assert lookup.call_count==2
            ff.lookup_research('Meter','M100',refresh=True);assert lookup.call_count==3
        ff.CACHE=old_cache
        old_outputs=cm.pm.OUTPUTS;cm.pm.OUTPUTS=Path(td)/'outputs'
        app=Flask(__name__);app.register_blueprint(cm.bp);c=app.test_client()
        r=c.post('/api/catalog/new',json={'name':'Draft test'}).json['record']
        path=cm.target(r['_id']);before=path.read_bytes()
        response=c.post('/api/catalog/autofill',json={'id':r['_id'],'name':'Draft test','model':'','mode':'local','specifications':[{'name':'Range','value':'100 V'}]})
        assert response.status_code==200,response.json
        job_id=response.json['job_id']
        for _ in range(100):
            job=c.get('/api/catalog/autofill/'+job_id).json
            if job['status']!='running':break
            time.sleep(.01)
        assert job['status']=='done',job
        assert path.read_bytes()==before,'Auto-fill must not save product edits'
        cm.pm.OUTPUTS=old_outputs
    browser=IndiaMartBrowser.__new__(IndiaMartBrowser)
    browser.publish_mode='auto';browser.event=lambda *a:None
    browser._click_final_publish_control=lambda: (_ for _ in ()).throw(AssertionError('Final submit must remain manual'))
    assert browser.finalize()['status']=='review_required'
    print('PASS: exact-model rejection, local-only fill, purchase-price exclusion, unknown fields, cache hit/isolation/refresh, asynchronous draft, no automatic record save, and manual seller submission even with auto setting.')
if __name__=='__main__':main()
