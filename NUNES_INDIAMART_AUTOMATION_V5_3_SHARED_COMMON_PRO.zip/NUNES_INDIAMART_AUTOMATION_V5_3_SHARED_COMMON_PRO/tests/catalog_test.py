"""Offline persistence and validation regression checks; uses temporary data."""
import io
import json
import sys
import tempfile
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from flask import Flask
from PIL import Image
import catalog_manager as cm

def main():
    old = cm.pm.OUTPUTS
    with tempfile.TemporaryDirectory() as td:
        cm.pm.OUTPUTS = Path(td)
        app=Flask(__name__,template_folder=str(Path(__file__).resolve().parents[1]/'templates'))
        app.register_blueprint(cm.bp)
        c=app.test_client()
        assert c.get('/products').status_code==200
        r=c.post('/api/catalog/new',json={'name':'Test meter'}).json['record']
        assert c.post('/api/catalog/new',json={'name':'Test meter'}).status_code==400
        path=cm.target(r['_id'])
        original=json.loads(path.read_text());original['custom_field']={'keep':True};original['source']['sheet_row']={'Price':'1','Purchase Price':'15'};original['assets']['pdf_path']='old.pdf';path.write_text(json.dumps(original))
        r=cm.read(r['_id'])
        payload={'id':r['_id'],'revision':r['_revision'],'listing_name':'Test meter renamed','model':'M1','price':'1200','categories':['Testing','Meters'],'specifications':[{'name':'Model','value':'WRONG'},{'name':'Range','value':'100'}]}
        assert c.post('/api/catalog/save',json={**payload,'categories':['A','B','C']}).status_code==400
        for price in ['-1','NaN','Infinity','abc']:
            assert c.post('/api/catalog/save',json={**payload,'price':price}).status_code==400
        saved=c.post('/api/catalog/save',json=payload);assert saved.status_code==200,saved.json
        r=saved.json['record']
        assert r['custom_field']=={'keep':True}
        assert r['source']['sheet_row']=={'Price':'1200','Purchase Price':'15','Selling Price':'1200'}
        assert r['approved']['specifications'][0]['value']=='M1'
        assert r['assets']['pdf_path']=='' and r['status']=='REVIEW_READY'
        assert len(list((path.parent/'backups').glob('*.json')))==1
        assert c.post('/api/catalog/save',json=payload).status_code==400
        for invalid in ['../escape','..','']:
            assert c.post('/api/catalog/save',json={**payload,'id':invalid}).status_code==400
        im=io.BytesIO();Image.new('RGB',(50,50),'white').save(im,format='PNG');im.seek(0)
        uploaded=c.post('/api/catalog/media',data={'id':r['_id'],'revision':r['_revision'],'kind':'image','file':(im,'test.png')});assert uploaded.status_code==200,uploaded.json
        r=uploaded.json['record'];assert Path(r['assets']['images'][0]).exists()
        deleted=c.post('/api/catalog/image-action',json={'id':r['_id'],'revision':r['_revision'],'index':0,'action':'remove'});assert deleted.status_code==200
        assert not deleted.json['record']['assets']['images']
        cm.BUSY=lambda:True
        assert c.post('/api/catalog/new',json={'name':'Blocked'}).status_code==409
        cm.BUSY=lambda:False
        assert len(c.get('/api/catalog').json['items'])==1
    cm.pm.OUTPUTS=old
    print('PASS: catalogue CRUD, duplicate prevention, price validation, model sync, two-category limit, backups, preservation, revision conflict, path checks, media upload/removal, busy guard and page render.')
if __name__=='__main__': main()
