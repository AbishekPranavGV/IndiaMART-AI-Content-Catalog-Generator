import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
os.chdir(ROOT)


def main():
    with tempfile.TemporaryDirectory() as td:
        os.environ['LOCALAPPDATA'] = td

        import indiamart_accounts as ia

        # A fresh install must not invent a fake default account.
        assert ia.load_accounts(include_legacy=True) == [], 'fresh dashboard should show zero seller accounts'

        for i in range(1, 8):
            ia.add_account(
                profile_directory=f'Profile {i}',
                label=f'Nunes Seller {i}',
                email=f'seller{i}@example.invalid',
                user_data_dir=str(Path(td) / 'Chrome' / 'User Data'),
            )

        accounts = ia.load_accounts(include_legacy=True)
        assert len(accounts) == 7, 'all seven configured seller accounts must be returned'
        assert len({x['id'] for x in accounts}) == 7, 'seller account ids must be unique'

        # Import app only after LOCALAPPDATA is isolated. The installed NUNES
        # venv has Flask; source-only validation environments may not.
        runtime_checked = False
        try:
            import flask  # noqa: F401
            import app as nunes_app
            client = nunes_app.app.test_client()

            status = client.get('/api/shared-status').get_json()
            assert status['ok'] is True
            assert status['centralized'] is True
            assert status['account_count'] == 7
            assert 'accounts' not in status, 'health endpoint must not expose seller metadata'

            staff = client.get('/api/indiamart/accounts', environ_base={'REMOTE_ADDR': '100.80.70.60'}).get_json()
            assert staff['access_mode'] == 'staff_host'
            assert staff['setup_allowed'] is False
            assert staff['account_count'] == 7
            assert len(staff['accounts']) == 7
            runtime_checked = True
        except ModuleNotFoundError as exc:
            if exc.name != 'flask':
                raise

        html = (ROOT / 'templates' / 'products.html').read_text(encoding='utf-8')
        assert 'accounts.slice(0,5)' not in html, 'dashboard must not truncate seller accounts to five'
        assert 'accounts.map(a=>' in html, 'dashboard should render the complete seller account list'

    print('PASS: fresh install has no phantom seller account')
    print('PASS: seven seller accounts are retained and returned')
    if runtime_checked:
        print('PASS: shared health endpoint reports count without seller details')
        print('PASS: remote staff mode cannot change account setup')
    else:
        print('SKIP: Flask runtime endpoint checks (Flask not installed in this source-only interpreter)')
    print('PASS: dashboard no longer truncates account coverage to five')
    print('SHARED DASHBOARD TEST PASSED')


if __name__ == '__main__':
    main()
