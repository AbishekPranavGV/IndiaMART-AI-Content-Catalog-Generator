NUNES IndiaMART Product Automation - FAST V3 EXACT TEMPLATE

START:
1. Extract the ZIP.
2. Double-click START_INSTANT.bat.
3. Generate the listing as before.
4. Upload/replace the product image.
5. Click Build Catalog.
6. Use Edit Catalog for final text/table edits.
7. Click Print / Save PDF.

REFERENCE TEMPLATE:
- Built-in reference: SILAR Coating System with Stirrer.pdf
- Catalog layout is locked to this supplied 2-page reference style:
  Page 1: NUNES header, centered product title, bordered product image, PRODUCT SPECIFICATION table.
  Page 2: PRODUCT DESCRIPTION, Key Features with pink bullets, original NUNES footer.
- Upload / Replace PDF remains available and remembers the selected reference PDF in the browser.

IMPORTANT:
- Existing IndiaMART listing generation, Copy/Edit, TXT, JSON, image prompts, and product-image editing are preserved.
- No npm, Python, server, installation, or build process is required.
